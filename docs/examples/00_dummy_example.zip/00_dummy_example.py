r"""
Dummy example
=============

This script check is the logo can be found when the gallery is generated
"""
import nrv

print(nrv.__version__)